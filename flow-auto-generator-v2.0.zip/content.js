// ===================================================
// Google Flow Auto Generator — Content Script v6
// Fix: Slate.js needs DataTransfer paste to register text in React state
// ===================================================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'injectPrompt') {
    handleGenerate(msg.prompt, msg.prefix, msg.index)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (msg.action === 'ping') {
    sendResponse({ ok: true });
    return true;
  }
});

async function handleGenerate(prompt, prefix, index) {
  log('Finding prompt input...');
  const inputEl = await waitFor(findPromptInput, 8000);
  if (!inputEl) throw new Error('Prompt input not found.');

  log('Clearing and pasting text via DataTransfer...');
  await slateType(inputEl, prompt);
  await sleep(600);

  // Verify Slate internal state has text
  const visible = inputEl.textContent?.replace(/\u200B/g, '').trim();
  log('Visible text: "' + visible + '"');

  log('Finding send button...');
  const sendBtn = await waitFor(findSendButton, 5000);
  if (!sendBtn) throw new Error('Send button not found.');

  log('Clicking send...');
  const snapshot = captureCurrentMedia();
  sendBtn.click();

  log('Waiting for generated output...');
  const mediaEl = await waitForNewMedia(snapshot, 120000);
  if (!mediaEl) throw new Error('No new image/video appeared after 120s.');

  await sleep(1500);
  const url = getMediaUrl(mediaEl);
  if (!url) throw new Error('Media found but URL is empty.');

  const filename = `${prefix}${String(index + 1).padStart(3, '0')}_${Date.now()}.${getExt(url, mediaEl)}`;
  log('Saving: ' + filename);
  await downloadMedia(url, filename);
  return { ok: true };
}

// ── Type into Slate.js using DataTransfer paste (the only reliable method) ────
async function slateType(el, text) {
  el.click();
  await sleep(150);
  el.focus();
  await sleep(150);

  // Step 1: Select all existing content
  document.execCommand('selectAll', false, null);
  await sleep(100);

  // Step 2: Use DataTransfer to paste — Slate.js intercepts 'paste' events
  // and reads from clipboardData, updating its own internal state correctly
  const dt = new DataTransfer();
  dt.setData('text/plain', text);

  const pasteEvent = new ClipboardEvent('paste', {
    bubbles: true,
    cancelable: true,
    clipboardData: dt
  });

  el.dispatchEvent(pasteEvent);
  await sleep(300);

  // Step 3: If paste didn't work (some browsers block it), fallback to
  // simulating individual key insertions via Input Events with proper inputType
  const after = el.textContent?.replace(/\u200B/g, '').trim();
  if (!after || after === 'What do you want to create?') {
    log('Paste event fallback — using insertText InputEvents...');

    // Clear first
    document.execCommand('selectAll', false, null);
    el.dispatchEvent(new InputEvent('beforeinput', {
      bubbles: true, cancelable: true,
      inputType: 'deleteContentBackward'
    }));
    document.execCommand('delete', false, null);
    await sleep(100);

    // Insert via beforeinput + input events (Slate.js handles these natively)
    el.dispatchEvent(new InputEvent('beforeinput', {
      bubbles: true, cancelable: true,
      inputType: 'insertText',
      data: text
    }));
    document.execCommand('insertText', false, text);
    el.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'insertText',
      data: text
    }));
    await sleep(200);
  }

  // Step 4: Final check — if STILL empty, use the nuclear option
  const final = el.textContent?.replace(/\u200B/g, '').trim();
  if (!final || final === 'What do you want to create?') {
    log('Nuclear fallback — direct Slate state injection...');
    await nuclearFallback(el, text);
  }

  await sleep(200);
  log('Final text in editor: "' + el.textContent?.replace(/\u200B/g, '').substring(0, 60) + '"');
}

// ── Nuclear fallback: simulate real keyboard typing ───────────────────────────
async function nuclearFallback(el, text) {
  // Focus and select all
  el.focus();
  document.execCommand('selectAll', false, null);

  // Fire beforeinput deleteContentBackward to clear
  el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'deleteContentBackward' }));
  document.execCommand('delete', false, null);
  await sleep(50);

  // Type one character at a time with full event chain
  for (const char of text) {
    const keyOpts = { key: char, code: 'Key' + char.toUpperCase(), bubbles: true, cancelable: true };
    el.dispatchEvent(new KeyboardEvent('keydown', keyOpts));
    el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: char }));
    document.execCommand('insertText', false, char);
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: char }));
    el.dispatchEvent(new KeyboardEvent('keyup', keyOpts));
    await sleep(8);
  }
}

// ── Find prompt input ─────────────────────────────────────────────────────────
function findPromptInput() {
  for (const el of document.querySelectorAll('[contenteditable="true"]')) {
    if (el.className?.includes('sc-a8ba1f43')) return el;
  }
  for (const el of document.querySelectorAll('div[role="textbox"][contenteditable="true"]')) {
    const r = el.getBoundingClientRect();
    if (r.top > window.innerHeight * 0.5 && r.width > 100) return el;
  }
  return null;
}

// ── Find send button ──────────────────────────────────────────────────────────
function findSendButton() {
  // Confirmed class from DOM inspection
  for (const btn of document.querySelectorAll('button')) {
    if (btn.className?.includes('sc-26b30722') && btn.offsetParent && !btn.disabled) return btn;
  }
  // Fallback: rightmost small button in bottom bar
  const vh = window.innerHeight;
  const btns = [...document.querySelectorAll('button')]
    .filter(b => {
      if (!b.offsetParent || b.disabled) return false;
      const r = b.getBoundingClientRect();
      return r.top > vh * 0.8 && r.width < 60;
    })
    .sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);
  return btns[0] || null;
}

// ── Media helpers ─────────────────────────────────────────────────────────────
function captureCurrentMedia() {
  const s = new Set();
  document.querySelectorAll('img[src],video[src]').forEach(e => s.add(e.src));
  return s;
}

function waitForNewMedia(prev, timeout = 120000) {
  return new Promise(resolve => {
    const t0 = Date.now();
    const check = () => {
      const found = [
        ...[...document.querySelectorAll('img[src]')].filter(i =>
          !prev.has(i.src) && looksGenerated(i.src) && i.naturalWidth > 100),
        ...[...document.querySelectorAll('video[src]')].filter(v =>
          !prev.has(v.src) && v.src)
      ];
      if (found.length) { resolve(found[found.length - 1]); return; }
      if (Date.now() - t0 > timeout) { resolve(null); return; }
      setTimeout(check, 2000);
    };
    setTimeout(check, 4000);
  });
}

function looksGenerated(src) {
  if (!src) return false;
  if (src.startsWith('blob:')) return true;
  if (src.includes('lh3.googleusercontent')) return true;
  if (src.includes('generativelanguage.googleapis')) return true;
  if (src.includes('aisandbox') || src.includes('labs.google')) return true;
  if (/\/(icon|logo|avatar|favicon|gstatic)/i.test(src)) return false;
  return src.length > 80;
}

function getMediaUrl(el) { return el.src || el.currentSrc || ''; }
function getExt(url, el) {
  if (el.tagName === 'VIDEO') return 'mp4';
  if (url.includes('.png')) return 'png';
  if (url.includes('.webp')) return 'webp';
  if (url.includes('.jpg') || url.includes('.jpeg')) return 'jpg';
  return 'png';
}

async function downloadMedia(url, filename) {
  try {
    const blob = await fetch(url).then(r => r.blob());
    const obj = URL.createObjectURL(blob);
    chrome.runtime.sendMessage({ action: 'download', url: obj, filename });
    setTimeout(() => URL.revokeObjectURL(obj), 10000);
  } catch {
    chrome.runtime.sendMessage({ action: 'download', url, filename });
  }
}

function waitFor(fn, ms = 8000, iv = 400) {
  return new Promise(resolve => {
    const t0 = Date.now();
    const tick = () => {
      const r = fn(); if (r) { resolve(r); return; }
      if (Date.now() - t0 > ms) { resolve(null); return; }
      setTimeout(tick, iv);
    };
    tick();
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function log(m) { console.log('[FlowExt v6]', m); }

log('v6 ready — Slate.js DataTransfer paste method active.');
